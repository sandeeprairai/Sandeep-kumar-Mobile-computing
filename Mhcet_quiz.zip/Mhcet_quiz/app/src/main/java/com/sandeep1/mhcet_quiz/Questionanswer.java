package com.sandeep1.mhcet_quiz;

public class Questionanswer {
    public static String question[] ={
            "SI unit for electnc charge is__________",
            " Mole is the SI unit of_______",
            "Candela is SI unit of_______",
            " Pascal (Pa) is SI unit of_______",
            "Which of the following is set of fundamental units?",
            "Which of the following is not a unit of length?",
            "N kg-1 is the unit of_______",
            "Which of the following is incorrect about S.l. units?",
            " The percentage of nitrogen in urea is about ________",
            "16g of gas occupies 5.6 dm3 at S. T. P. The gas may be______"









    };

    public static String choices[][] = {
            {"Erg","Joule","calorie","coulomb"},
            {"concentration","amount of substance" ," mass", "density"},
            {" electric current","Energy","luminous intensity ","potential difference"},
            {" Force","pressure","concentration","heat capacity"},
            {"mass volume,temperature","temperature,time length","density,heat,time","luminous intensity,mass,heat,capacity"},
            {"angstrom","radian","micron","light year"},
            {"momentum","velocity","pressure","Acceleration"},
            {" density in kg m","force in Newtons","pressure in pascals","amount of the substance in mol L"},
            {"85","46","18","28"},
            {"oxygen","molecules","both a and b","none"}

    };

    public static String correctAnswers[] = {
            "colulomb",
            " Amount of substance",
            "luminous intensity",
            "pressure",
            "temperature,time length",
            "radian",
            "Acceleration",
            "amount of the substance in mol L",
            "46",
            "oxygen"







    };
}
